package extrace.ui.main;

/**
 * Created by chao on 2016/4/16.
 */
public class MainPresenterImpl implements MainPresenter {

    MainView mainView;
    public MainPresenterImpl(MainView mainView){
        this.mainView = mainView;
    }
}
