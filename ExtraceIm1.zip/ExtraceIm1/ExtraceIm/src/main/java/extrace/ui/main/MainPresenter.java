package extrace.ui.main;

/**
 * Created by chao on 2016/4/16.
 */
public interface MainPresenter {
}
