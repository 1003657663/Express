package extrace.model;

/**
 * Created by chao on 2016/4/15.
 * 点击跳转到某一界面，然后处理事务比如登陆，注册之后，再跳回原界面
 * 保存 来自哪一个界面的跳转标志位
 */
public class JumpFromAndTo {

}
