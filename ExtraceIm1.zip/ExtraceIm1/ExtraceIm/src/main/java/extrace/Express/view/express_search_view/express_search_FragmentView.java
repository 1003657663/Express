package extrace.Express.view.express_search_view;

import android.app.Activity;

/**
 * Created by 黎明 on 2016/4/17.
 */
public interface express_search_FragmentView
{
    public void onToastSuccess();
    public void onToastFail();
    public Activity getTheActivity();
}
