package extrace.Express.model.express_search;

/**
 * Created by 黎明 on 2016/4/17.
 */
public interface expressListModel
{
    public void searchExpressList(String ID);
    //根据 手机号、ID等查询express-list
}
