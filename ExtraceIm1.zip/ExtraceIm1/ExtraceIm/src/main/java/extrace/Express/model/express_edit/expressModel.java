package extrace.Express.model.express_edit;

/**
 * Created by 黎明 on 2016/4/16.
 */
public interface expressModel
{
    public void newExpress(int senderID, int receiveID);
    //根据两个地址ID创建express
}
