package extrace.Express.view.express_edit_view;

import android.app.Activity;

/**
 * Created by 黎明 on 2016/4/16.
 */
public interface express_edit_FragmentView
{
    public void onToastSuccess();
    public void onToastFail();
    public Activity getTheActivity();
}
